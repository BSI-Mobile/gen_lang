package com.kingwu.genlangexample

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

}

